﻿using System;
using SilverFlow.Controls;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : FloatingWindow
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
