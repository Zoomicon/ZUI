﻿Imports System
Imports SilverFlow.Controls

Namespace $rootnamespace$

    Public Partial Class $safeitemname$ 
        Inherits FloatingWindow

        Public Sub $safeitemname$()
            InitializeComponent()
        End Sub

    End Class

End Namespace
